import {BrowserRouter,Routes,Route,NavLink,Link} from "react-router-dom";
import data from "./data.json";
import HeroDetailsComp from "./herodetail";
let App = ()=>{
    return <>
    <div>
        <h1>Heroes list</h1>
        <BrowserRouter>
            <h2>
                
                {
                    data.heroes.map((val,idx)=>{
                       return  <li key={idx}>
                            <Link to={"/details/"+val.id} >{val.name}</Link>
                            </li>
                    })
                }
                </h2>
            
                <Routes>
                    <Route path="/details" element={<HeroDetailsComp/>}></Route>
                    <Route path="/details/:id" element={<HeroDetailsComp/>}></Route>
                </Routes>

        </BrowserRouter>
    </div>
    
    </> 
}
export default App
 
import { useParams } from "react-router-dom"
import {BrowserRouter,Routes,Route,NavLink} from "react-router-dom";
import App from "./app";
 import data from "./data.json";
let HeroDetailsComp = ()=>{
    let prms = useParams();
    return <div> 
    
        <h1>Details </h1>
        {
            data.heroes.map((val,idx)=>{
                if(val.id == prms.id){
                    return <div>
                            <ul>
                            <h1>Name : {val.name} <br /></h1>
                            <h2>Power </h2>
                            combat  : {val.powerstats.combat} <br />
                            intelligence  : {val.powerstats.intelligence} <br />
                            durability : {val.powerstats.durability} <br />
                            power : {val.powerstats.power} <br />
                            speed : {val.powerstats.speed} <br />
                            strength : {val.powerstats.strength} <br />
                            </ul>
                    </div>
                }
            })
        }

    </div>
}
export default HeroDetailsComp;